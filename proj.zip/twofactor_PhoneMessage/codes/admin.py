from django.contrib import admin
from codes.models import Code

# Register your models here.
admin.site.register(Code)