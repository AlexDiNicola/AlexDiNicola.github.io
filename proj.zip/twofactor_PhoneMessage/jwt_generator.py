import jwt
import datetime


def create_token(user):
    token = jwt.encode(
        {
            'exp': datetime.datetime.utcnow() + datetime.timedelta(minutes=10),
            'iat': datetime.datetime.utcnow(),
            'sub': user
        },'secret', algorithm='HS256')
    return token

def decode_token(token):
    try:
        payload = jwt.decode(token, 'secret', algorithms=['HS256'])
        return payload['sub']
    except jwt.ExpiredSignatureError:
        return 'Signature expired. Please log in again.'
    except jwt.InvalidTokenError:
        return

