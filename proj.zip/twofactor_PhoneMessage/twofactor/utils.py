import os
from twilio.rest import Client

# Your Account SID from twilio.com/console
#and set

account_sid = 'AC467c135bffb5e78af4b236652e830764'
auth_token = 'cfb16363c31ff210a480efa1c84189ea'
client = Client(account_sid, auth_token)


def send_sms(user_code, phone_number):
    message = client.messages.create(
            body=f"Hi! Your code is {user_code}",
            from_="+19892817945",
            to=f'{phone_number}'
        )
    print(message.sid)